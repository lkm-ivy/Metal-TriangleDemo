//
//  ViewController.h
//  MetalCodeDemo-00
//
//  Created .
//  Copyright ©  All rights reserved.
//

#import <UIKit/UIKit.h>
@import MetalKit;
#import "CCRenderer.h"

@interface ViewController : UIViewController


@end

